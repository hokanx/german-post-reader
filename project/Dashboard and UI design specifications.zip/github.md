repo: hokanx/german-post-reader
branch: main
path: project/src

## Last sync

date: 2026-08-10T06:39:25Z

### Updated in this project

- Recreated today's mobile screens (dashboard, letter analysis, deadlines, settings, onboarding) from source.
- Proposed a deadline-first dashboard and a restructured letter output with German source under each claim.
- Designed a guided two-question reply workflow with always-visible German + English.
- Sketched roadmap surfaces: reply PDF (Stage 2), calendar sync (Stage 3), family plan seats (Stage 4).

## Screen map

| Screen | Repo files |
|---|---|
| 1a Dashboard | project/src/app/(app)/dashboard/page.tsx, dashboard/letter-list.tsx, components/app-header.tsx, components/app-nav.tsx, components/empty-state.tsx |
| 1b Letter analysis | project/src/app/(app)/letters/[id]/page.tsx, letters/[id]/reply-draft-card.tsx, letters/[id]/copy-reply-button.tsx, lib/letters/types.ts |
| 1c Deadlines | project/src/app/(app)/deadlines/page.tsx, lib/letters/flatten-deadlines.ts |
| 1d Settings | project/src/app/(app)/settings/page.tsx, components/language-switcher.tsx, components/logout-button.tsx |
| 1e Onboarding | project/src/app/onboarding/page.tsx, onboarding/language-picker.tsx |
| Tokens & copy (all screens) | project/src/app/globals.css, project/src/app/layout.tsx, project/src/lib/i18n/copy.ts, project/src/lib/constants.ts, project/design-system/MASTER.md, SPEC.md |
| 2a–2f Proposals | derived from the above + SPEC.md later stages |
